package com.baha.askai;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    TextView tv(String t, int sp, boolean bold) {
        TextView x = new TextView(this);
        x.setText(t);
        x.setTextSize(sp);
        x.setTextColor(Color.WHITE);
        x.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        x.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        if (bold) x.setTypeface(null, android.graphics.Typeface.BOLD);
        x.setPadding(0, dp(8), 0, dp(4));
        return x;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#0f172a"));
        getWindow().setNavigationBarColor(Color.parseColor("#0f172a"));
        final SharedPreferences sp = getSharedPreferences("cfg", 0);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#0f172a"));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));
        sv.addView(root);

        root.addView(tv("اسأل الذكاء الاصطناعي", 22, true));
        root.addView(tv("حدّد أي نص في أي تطبيق (بالضغط المطوّل عليه)، ثم اختر \"اسأل الذكاء الاصطناعي\" من شريط الخيارات فوق النص (قد يكون داخل زر ⋮ أو \"المزيد\").", 14, false));

        root.addView(tv("مفتاح Groq API", 15, true));
        final EditText key = new EditText(this);
        key.setHint("gsk_...");
        key.setTextColor(Color.WHITE);
        key.setHintTextColor(Color.GRAY);
        key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        key.setText(sp.getString("key", ""));
        root.addView(key);

        Button get = new Button(this);
        get.setText("احصل على مفتاح مجاني من Groq");
        get.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://console.groq.com/keys"))));
        root.addView(get);

        root.addView(tv("النموذج", 15, true));
        final EditText model = new EditText(this);
        model.setTextColor(Color.WHITE);
        model.setText(sp.getString("model", "llama-3.3-70b-versatile"));
        root.addView(model);

        Button save = new Button(this);
        save.setText("حفظ");
        save.setOnClickListener(v -> {
            String m = model.getText().toString().trim();
            sp.edit().putString("key", key.getText().toString().trim())
                    .putString("model", m.isEmpty() ? "llama-3.3-70b-versatile" : m).apply();
            Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show();
        });
        root.addView(save);

        setContentView(sv);
    }
}
